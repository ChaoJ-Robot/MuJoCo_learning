#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseStamped, Point, Quaternion
from std_msgs.msg import Float64MultiArray

from .gen3_robot_core import Gen3Robot


class Gen3RobotNode(Node):
    def __init__(self):
        super().__init__('gen3_robot_node')

        # 获取参数
        self.declare_parameter('model_xml_path', '')
        model_xml_path = self.get_parameter('model_xml_path').value

        if not model_xml_path:
            self.get_logger().error('模型文件路径未指定')
            raise ValueError('model_xml_path 参数为空')

        # 初始化 MuJoCo 机器人
        self.robot = Gen3RobotROS(model_xml_path, self)

        # 设置发布器
        self._setup_publishers()

        # 设置订阅器
        self._setup_subscribers()

        # 100 Hz 定时器
        self.timer = self.create_timer(0.01, self._timer_callback)

        self.get_logger().info('Gen3 Robot ROS2 节点已启动')

    def _setup_publishers(self):
        """设置 ROS2 发布器"""
        self.joint_state_pub = self.create_publisher(
            JointState,
            'joint_states',
            10
        )

        self.ee_pose_pub = self.create_publisher(
            PoseStamped,
            'ee_pose',
            10
        )

    def _setup_subscribers(self):
        """设置 ROS2 订阅器"""
        self.joint_target_sub = self.create_subscription(
            Float64MultiArray,
            'joint_target',
            self._joint_target_callback,
            10
        )

        self.ee_pose_target_sub = self.create_subscription(
            PoseStamped,
            'ee_pose_target',
            self._ee_pose_target_callback,
            10
        )

    def _joint_target_callback(self, msg):
        """关节目标回调"""
        try:
            if len(msg.data) == 7:
                self.robot.set_joint_target(list(msg.data))
            else:
                self.get_logger().warn('关节目标数据长度必须为 7')
        except Exception as e:
            self.get_logger().error(f'设置关节目标失败: {e}')

    def _ee_pose_target_callback(self, msg):
        """末端位姿目标回调"""
        try:
            position = [
                msg.pose.position.x,
                msg.pose.position.y,
                msg.pose.position.z
            ]

            # 这里先只传位置，旋转后续再补
            self.robot.set_ee_pose(position)
        except Exception as e:
            self.get_logger().error(f'设置末端位姿目标失败: {e}')

    def _timer_callback(self):
        """定时器回调：发布状态并推进仿真"""
        try:
            self._publish_joint_state()
            self._publish_ee_pose()
            self.robot.step()
        except Exception as e:
            self.get_logger().error(f'定时器回调错误: {e}')

    def _publish_joint_state(self):
        """发布关节状态"""
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = [
            'joint_1', 'joint_2', 'joint_3', 'joint_4',
            'joint_5', 'joint_6', 'joint_7'
        ]

        state = self.robot.get_state()

        msg.position = list(state['qpos'])
        msg.velocity = list(state['qvel'])
        msg.effort = list(state['ctrl'])

        self.joint_state_pub.publish(msg)

    def _publish_ee_pose(self):
        """发布末端位姿"""
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'

        ee_pos, ee_rot = self.robot.get_ee_pose()

        msg.pose.position = Point(
            x=float(ee_pos[0]),
            y=float(ee_pos[1]),
            z=float(ee_pos[2])
        )

        # 暂时使用单位四元数
        msg.pose.orientation = Quaternion(
            x=0.0, y=0.0, z=0.0, w=1.0
        )

        self.ee_pose_pub.publish(msg)


class Gen3RobotROS:
    """对 Gen3Robot 的 ROS2 包装"""

    def __init__(self, model_xml_path, node):
        self.node = node
        self.robot = Gen3Robot(model_xml_path)
        self.node.get_logger().info(f'MuJoCo Gen3 机器人已初始化，模型: {model_xml_path}')

    def set_joint_target(self, q_target):
        return self.robot.set_joint_target(q_target)

    def set_ee_pose(self, pos_des, rot_des=None):
        return self.robot.set_ee_pose(pos_des, rot_des)

    def get_state(self):
        return self.robot.get_state()

    def get_ee_pose(self):
        return self.robot.get_ee_pose()

    def step(self, nstep=1):
        return self.robot.step(nstep)


def main(args=None):
    rclpy.init(args=args)
    node = None

    try:
        node = Gen3RobotNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f'节点错误: {e}')
    finally:
        if node is not None:
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()